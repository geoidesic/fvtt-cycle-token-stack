# CHANGELOG

## [0.4.1] 2020-07-23
### ADDED
### BUGFIXES
- Keyboard shortcut would continue to trigger cycle when user opened character sheet.
- Third click would not invoke a cycle on a stack of tokens, usually after F5 pressed.

## [0.4.0] 2020-07-20
### ADDED
- Initial Release
- Added keyboard shortcut for cycling.